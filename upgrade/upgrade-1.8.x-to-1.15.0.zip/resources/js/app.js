// import './bootstrap.js';
import './utility.js';
import './localization.js';
import './forms.js';
import './image-upload.js';
import './qrcode.js';
import './qrscanner.js';
import './alpine/alpine.js';
import './tw-elements/tw-elements.js';
import './flowbite/flowbite.js';

import 'flag-icons';
import 'htmx.org';