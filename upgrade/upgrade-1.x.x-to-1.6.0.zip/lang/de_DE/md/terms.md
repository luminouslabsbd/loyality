# Nutzungsbedingungen

Willkommen bei unserer Kundenbindungsanwendung! Durch den Zugriff auf unsere Anwendung oder deren Nutzung erklären Sie sich mit den folgenden Bedingungen und Konditionen einverstanden.

- Sie müssen mindestens 13 Jahre alt sein, um unsere Anwendung zu nutzen.
- Sie dürfen unsere Anwendung nicht für illegale oder unbefugte Zwecke verwenden.
- Sie sind für alle Aktivitäten verantwortlich, die über Ihr Konto erfolgen.
- Sie dürfen keine Würmer, Viren oder einen zerstörerischen Code übertragen.
- Wir behalten uns das Recht vor, den Service jederzeit aus beliebigen Gründen ohne vorherige Ankündigung zu ändern oder einzustellen.
- Wir behalten uns das Recht vor, jedem aus beliebigen Gründen und zu jeder Zeit den Service zu verweigern.
- Wir garantieren nicht die Verfügbarkeit oder Betriebszeit unserer Anwendung.
- Sie dürfen keine Materialien unserer Anwendung vervielfältigen, verteilen, modifizieren, abgeleitete Werke erstellen, öffentlich anzeigen, öffentlich vorführen, veröffentlichen, herunterladen, speichern oder übertragen, es sei denn, dies ist gesetzlich gestattet.
- Sie dürfen nicht auf die Server unserer Anwendung zugreifen oder in eines ihrer Systeme eindringen.
- Wir übernehmen keine Gewährleistung für Vollständigkeit, Richtigkeit, Zuverlässigkeit, Eignung oder Verfügbarkeit in Bezug auf unsere Anwendung oder die Informationen, Produkte, Dienstleistungen oder damit verbundenen Grafiken auf unserer Anwendung für einen bestimmten Zweck.

Durch den Zugriff auf unsere Anwendung oder deren Nutzung bestätigen Sie, dass Sie diese Bedingungen und Konditionen gelesen und verstanden haben und sich daran gebunden fühlen. Wenn Sie diesen Bedingungen und Konditionen nicht zustimmen, nutzen Sie bitte unsere Anwendung nicht.

Wir behalten uns das Recht vor, diese Bedingungen und Konditionen jederzeit zu aktualisieren. Ihre fortgesetzte Nutzung unserer Anwendung gilt als Annahme solcher Änderungen.

Vielen Dank, dass Sie unsere Kundenbindungsanwendung nutzen!