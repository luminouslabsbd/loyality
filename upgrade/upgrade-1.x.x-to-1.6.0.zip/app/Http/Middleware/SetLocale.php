<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;

class SetLocale
{
    /**
     * Handle an incoming request and set the application's locale.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {
        // Set locale from request header or use default locale
        $locale = app()->runningInConsole()
            ? config('app.locale')
            : $request->header('locale', null);

        if (! $locale && $request->segment(1)) {
            // Extract locale from URL segment
            $locales = explode('-', $request->segment(1));
            $locale = isset($locales[1])
                ? $locales[0].'_'.strtoupper($locales[1])
                : config('app.locale');

            // Redirect to 'redir.locale' route if translation file does not exist, or if first segment does not match locale
            if (! File::exists(lang_path().'/'.$locale) || $request->segment(1) !== strtolower(str_replace('_', '-', $locale))) {
                return redirect()->route('redir.locale');
            }
        }

        // Set the application's locale
        if ($locale) {
            app()->setLocale($locale);
            \Carbon\Carbon::setLocale($locale);
        }

        return $next($request);
    }
}
